//
// Instructor: Sai-Keung WONG
// Email: cswingo@cs.nctu.edu.tw
// Assembly Language 
//
#ifndef __OPENGL_STUFF
#define __OPENGL_STUFF
#include <windows.h>
#include <time.h>
#include <math.h>
#include <GL/gl.h>
#include <GL/glut.h>
#include <string>
namespace ns_myProgram{
extern void initGL(int argc, char *argv[], std::string p_Title);
};
#endif