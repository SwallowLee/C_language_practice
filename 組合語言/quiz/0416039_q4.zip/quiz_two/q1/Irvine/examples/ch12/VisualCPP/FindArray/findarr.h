// findarr.h

extern "C" {

bool AsmFindArray( long n, long array[], long count );
// Assembly language version

bool FindArray( long n, long array[], long count );
// C++ version
}