#include"oop_string.h"
#include<algorithm>
#include<functional>

namespace oop{
  void reverse( std::string &str){
  }

  void toUpperCase( std::string &str){
  }
  
  void trim( std::string &str){
  }
};

