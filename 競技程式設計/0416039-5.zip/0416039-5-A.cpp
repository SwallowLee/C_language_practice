# include<iostream>
# include<algorithm>

using namespace std;
int main(void)
{
    int num,i,same,yes=0;
    cin>>num;
    int fight[num];
    for(i=0;i<num;i++)
    {
        cin>>fight[i];
    }
    sort(fight,fight+num);
    for(i=0;i<num;i++)
    {
        if(fight[i]<=yes)
            yes++;
        else
        {
            same=i;
            for(;i<num-1;i++)
            {
                if(fight[i]==fight[i+1])
                    same++;
                else
                {
                    break;
                }
            }
            if(fight[i]<=same)
                yes=same+1;//plus myself
        }
    }
    cout<<yes<<endl;
    return 0;
}
