# include<iostream>
# include<algorithm>
# include<vector>

using namespace std;
using std::vector;
struct now_point
{
  int first;
  int last;
};
vector<struct now_point> point,ans;
struct now_point insert;
int total,final,ans_num;
vector<struct now_point>::iterator it;
void find(int front,int first_point);
bool compare(struct now_point front,struct now_point behind)
{
    return (front.first<behind.first);
}
int main(void)
{
    int test,num1,num2,now;
    vector<struct now_point>::iterator it;
    cin>>test;
    while(test!=0)
    {
        cin>>final>>num1>>num2;
        total=0;
        ans_num=0;
        while(num1!=0||num2!=0)
        {
            insert.first=num1;
            insert.last=num2;
            point.push_back(insert);
            total++;
            cin>>num1>>num2;
        }
        sort(point.begin(),(point.begin()+total),compare);
        find(0,0);
        cout<<ans_num<<endl;
        if(ans_num>0)
        {
            for(it=ans.begin();it!=ans.end();it++)
            {
                cout<<it->first<<" "<<it->last<<endl;
            }
            for(it=ans.end()-1;it>=ans.begin();it--)
            {
                ans.pop_back();
            }
        }
        cout<<endl;
        for(it=point.end()-1;it>=point.begin();it--)
        {
            point.pop_back();
        }
        test--;
    }
    return 0;
}

void find(int front,int first_point)
{
    int i,j,max_point;
    static int stop=0;
    pair<int,int> max;
    for(i=first_point;i<total;i++)
    {
        if(front<point[i].first)
        {
            if(i==first_point)
            {
                if(ans.back().last<final)
                {
                    if(ans_num!=0)
                    {
                        for(it=ans.end()-1;it>=ans.begin();it--)
                        {
                            ans.pop_back();
                        }
                    }
                    ans_num=0;
                }
                return;
            }
            break;
        }
    }
    if(point[i-1].last>front)
    {
        max.first=point[first_point].first;
        max.second=point[first_point].last;
        for(j=first_point;j<i;j++)
        {
            if(max.second<point[j].last)
            {
                max.first=point[j].first;
                max.second=point[j].last;
            }
        }
        insert.first=max.first;
        insert.last=max.second;
        ans.push_back(insert);
        ans_num++;
        if(ans.back().last<final&&j<(total-1))
        {
            find(ans.back().last,i);
        }
        else if(ans.back().last<final)
        {
            if(ans_num!=0)
            {
                for(it=ans.end()-1;it>=ans.begin();it--)
                {
                    ans.pop_back();
                }
            }
            ans_num=0;
        }
    }
    else
    {
        if(front<final&&(i+1)<(total-1))
        {
            find(front,i+1);
        }
        else if(front<final)
        {
            if(ans_num!=0)
            {
                for(it=ans.end()-1;it>=ans.begin();it--)
                {
                    ans.pop_back();
                }
            }
            ans_num=0;
        }
    }
    return;
}
