# include<iostream>

using namespace std;
int main(void)
{
    int num,i,j,k,m,max,sum;
    cin>>num;
    int array[num][num],ans[num][num];
    for(i=0;i<num;i++)
        for(j=0;j<num;j++)
            cin>>array[i][j];
    ans[0][0]=array[0][0];
    max=ans[0][0];
    for(i=1;i<num;i++)
    {
        ans[0][i]=ans[0][i-1]+array[0][i];
        ans[i][0]=ans[i-1][0]+array[i][0];
        if(max<ans[0][i])
            max=ans[0][i];
        if(max<ans[i][0])
            max=ans[i][0];
    }
    for(i=1;i<num;i++)
        for(j=1;j<num;j++)
        {
            ans[i][j]=ans[i-1][j]+ans[i][j-1]-ans[i-1][j-1]+array[i][j];
            if(max<ans[i][j])
                max=ans[i][j];
        }
    for(i=-1;i<num-1;i++)
    {
        for(j=-1;j<num-1;j++)
        {
            if(i==-1)
            {
                if(j==-1)
                    continue;
                else
                    for(k=0;k<num;k++)
                        for(m=j+1;m<num;m++)
                        {
                            sum=ans[k][m]-ans[k][j];
                            if(max<sum)
                                max=sum;
                        }
            }
            else if(j==-1)
            {
                for(m=0;m<num;m++)
                    for(k=i+1;k<num;k++)
                    {
                        sum=ans[k][m]-ans[i][m];
                        if(max<sum)
                            max=sum;
                    }
            }
            else
                for(k=i+1;k<num;k++)
                {
                    for(m=j+1;m<num;m++)
                    {
                        sum=ans[k][m]-ans[k][j]-ans[i][m]+ans[i][j];
                        if(max<sum)
                            max=sum;
                    }
                }
        }
    }
    cout<<max<<endl;
    return 0;
}
