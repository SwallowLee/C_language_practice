# include<iostream>
# include<vector>

using namespace std;
using std::vector;
int main(void)
{
    int i,test,a,b,city,road;
    long long int earn,big;
    vector<int> pass;
    vector<int>::iterator it;
    cin>>test;
    while(test!=0)
    {
        cin>>city>>road;
        long long int people[city];
        bool run[city];
        vector<int> have_road[city];
        earn=0;
        big=0;
        for(i=0;i<city;i++)
        {
            cin>>people[i];
            run[i]=false;
        }
        for(i=0;i<road;i++)
        {
            cin>>a>>b;
            have_road[a-1].push_back(b-1);
            have_road[b-1].push_back(a-1);
        }
        for(i=0;i<city;i++)
        {
            if(run[i]==false)
            {
                earn=people[i];
                pass.push_back(i);
                run[i]=true;
                while(!pass.empty())
                {
                    int j=pass.back();
                    pass.pop_back();
                    for(it=have_road[j].begin();it!=have_road[j].end();it++)
                        if(run[*it]==false)
                        {
                            pass.push_back(*it);
                            run[*it]=true;
                            earn+=people[*it];
                        }
                }
                if(earn>big)
                    big=earn;
            }
        }
        cout<<big<<endl;
        for(i=0;i<city;i++)
            while(!have_road[i].empty())
                have_road[i].pop_back();
        test--;
    }
    return 0;
}
