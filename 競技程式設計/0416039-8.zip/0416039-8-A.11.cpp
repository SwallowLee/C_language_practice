# include<iostream>
# include<vector>

using namespace std;
using std::vector;
void access(int vertice,vector<int> *dot,bool *run,int investigate);
int main(void)
{
    int j,vertice,total,start,follow,find,investigate;
    cin>>vertice;
    while(vertice!=0)
    {
        vector<int> dot[vertice];
        vector<int>::iterator it;
        cin>>start;
        while(start!=0)
        {
            cin>>follow;
            while(follow!=0)
            {
                dot[start-1].push_back(follow-1);
                cin>>follow;
            }
            cin>>start;
        }
        cin>>find;
        vector<int> ans[find];
        j=0;
        while(find!=0)
        {
            bool run[vertice];
            cin>>investigate;
            for(int i=0;i<vertice;i++)
                run[i]=false;
            access(vertice,dot,run,investigate-1);
            ///////////////////
            total=0;
            for(int i=0;i<vertice;i++)
                if(run[i]==false)
                    total++;
            ans[j].push_back(total);
            for(int i=0;i<vertice;i++)
                if(run[i]==false)
                    ans[j].push_back(i+1);
            j++;
            ////////////////////
            find--;
        }
        for(int i=0;i<j;i++)
        {
            for(it=ans[i].begin();it!=ans[i].end()-1;it++)
                cout<<*it<<" ";
            cout<<*it<<endl;
            while(!ans[i].empty())
                ans[i].pop_back();
        }
        for(int i=0;i<vertice;i++)
            while(!dot[i].empty())
                dot[i].pop_back();
        cin>>vertice;
    }
}

void access(int vertice,vector<int> *dot,bool *run,int investigate)
{
    vector<int>::iterator it;
    for(it=dot[investigate].begin();it!=dot[investigate].end();it++)
        if(run[*it]==false)
        {
            run[*it]=true;
            access(vertice,dot,run,*it);
        }
}
