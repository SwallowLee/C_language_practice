# include<iostream>

using namespace std;
bool run[50][50];
char set[50][50];
int weight,height;

void dfs(int y,int x)
{
    int d;
    const int dy[]={-1,0,1,0},dx[]={0,-1,0,1};
    for(d=0;d<4;d++)
    {
        int ny=y+dy[d],nx=x+dx[d];
        if(ny<0||nx<0||ny>=height||nx>=weight||set[ny][nx]!='#'||run[ny][nx])
            continue;
        run[ny][nx]=true;
        dfs(ny,nx);
    }
}

bool check()
{
    int i,j;
    for(i=0;i<50;i++)
        for(j=0;j<50;j++)
            run[i][j]=false;
    int count=0;
    for(i=0;i<height;i++)
    {
        for(j=0;j<weight;j++)
        {
            if(set[i][j]=='#'&&!run[i][j])
            {
                run[i][j]=true;
                dfs(i,j);
                count++;
            }
        }
    }
    return count>1;
}

int main(void)
{
    int i,j;
    cin>>height>>weight;
    for(i=0;i<height;i++)
    {
        for(j=0;j<weight;j++)
        {
            cin>>set[i][j];
        }
    }
    int count=0;
    for(i=0;i<height;i++)
    {
        for(j=0;j<weight;j++)
        {
            if(set[i][j]=='#')
                count++;
        }
    }
    if(count<3)
    {
        cout<<"-1"<<endl;
        return 0;
    }
    for(i=0;i<height;i++)
    {
        for(j=0;j<weight;j++)
        {
            if(set[i][j]=='#')
            {
                set[i][j]='.';
                if(check())
                {
                    cout<<1<<endl;
                    return 0;
                }
                set[i][j]='#';
            }
        }
    }
    cout<<2<<endl;

    return 0;
}
