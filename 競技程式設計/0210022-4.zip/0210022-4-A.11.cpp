#include <iostream>

#define MOD_CONST 100000007

using namespace std;

long long modpow(int x, int y);

int main(void)
{
	int n;
	cin >> n;
	while(n--) {
		int level;
		cin >> level;
		cout << modpow(3,level)-1 << endl;
	}
}

long long modpow(int x, int y)
{
	if (y==0) return 1;
	else if (y==1) return x%MOD_CONST;
	else {
		long long output=modpow(x,y/2);
		if (y%2) {
			long long tmp=output*output%MOD_CONST;
			return tmp*x%MOD_CONST;
		}
		else return output*output%MOD_CONST;
	}
}

