#include <iostream>
#include <cstdio>

using namespace std;

bool trial(int* road, int w, int n, int m, int x);

int road[100000];
int main(void)
{
	int num;
	scanf("%d", &num);

	while(num--) {
		int n, w, m;
		int max_height=0;
		int* it=road;

		cin >> n >> w >> m;
		for(int i=0; i<n; ++i, ++it) {
			scanf("%d", it);
			if (*it>max_height) {
				max_height=*it;
			}
		}

		int upper, lower;
		upper=max_height;
		lower=0;
		for(int mid=max_height/2; lower<upper; mid=(upper+lower)/2) {
			if (trial((int*) road, w, n, m, mid)) {
				upper=mid;
			}
			else {
				lower=mid+1;
			}
		}

		if (lower!=n && trial((int*) road, w, n, m, lower)) {
			cout << lower << endl;
		}
		else {
			cout << -1 << endl;
		}
	}
}

bool trial(int* road, int w, int n, int m, int x)
{
	int indicator=0; // first uneven road
	int copy_road[n];

	for(int i=0; i<n; ++i) {
		copy_road[i]=road[i];
	}

	while(m--) {
		// search for next uneven road
		while(indicator<=n && copy_road[indicator]<=0) ++indicator;

		if (indicator>=n) return true;
		else {
			for(int i=0; i<w && (indicator+i)<100000; ++i) {
				copy_road[indicator+i]-=x;
			}
		}
	}

	while(indicator<=n && copy_road[indicator]<=0) ++indicator;
	if (indicator<n) return false;
	else return true;
}