#include <cstdio>
#include <algorithm>
#include <iostream>

using namespace std;

int gcd(int a, int b);
pair<int, int> extended_gcd(int x, int y);

int main(void)
{
	int m,n;
	int gcd_m_n;
	cin >> m >> n;

	if (m==1 && n==1) {
		cout << 1 << endl;
		return 0;
	}
	else if (m==1 || n==1) {
		cout << 2 << endl;
		return 0;
	}

	gcd_m_n=gcd(m,n);

	if (gcd_m_n>1) {
		cout << (long long)m*n/gcd_m_n << endl;
		return 0;
	}
	else {
		pair<int, int> tmp(std::move(extended_gcd(m, n)));

		if (tmp.first>0) cout << (long long)(tmp.first)*m << endl;
		else cout << (long long)(tmp.second)*n << endl;
	}

	return 0;
}

int gcd(int a, int b)
{
	if (a==1 || b==1) return 1;
	else if (a==b || b==0) return a;
	else if (a>b) return gcd(b, a%b);
	else return gcd(a, b%a);
}

pair<int, int> extended_gcd(int x, int y)
{
	if (x<y) {
		pair<int, int> tmp(std::move(extended_gcd(y, x)));
		return make_pair(tmp.second, tmp.first);
	}
	if (x%y==1) {
		return make_pair(1, (x/y)*(-1));
	}
	else {
		pair<int, int> tmp(std::move(extended_gcd(y, x%y)));
		return make_pair(tmp.second, tmp.first-tmp.second*(x/y));
	}
}