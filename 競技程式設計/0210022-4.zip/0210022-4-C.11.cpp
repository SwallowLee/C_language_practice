#include <cstdio>
#include <iostream>

using namespace std;

void mergesort(int begin, int end);
void merge(int begin, int end, int med);

long long count=0;
int input[100001];
int temp[100001];

int main(void)
{
	int num;
	scanf("%d", &num);
	while(num--) {
		int length;
		scanf("%d", &length);

		int* end=(int*)input+length;
		for(int* it=input; it!=end; ++it) {
			scanf("%d", it);
		}

		count=0;
		mergesort(0, length);
		printf("%lld\n", count);
	}
}

void mergesort(int begin, int end)
{
	if ((end-begin)<=1) return;

	int med=(begin+end)/2;
	mergesort(begin, med);
	mergesort(med, end);
	merge(begin, end, med);

}

void merge(int begin, int end, int med)
{
	int i=begin;
	int j=med;
	int cur=begin;

	while(i<med && j<end) {
		if (input[i]<=input[j]) {
			temp[cur]=input[i];
			++i;
		}
		else {
			temp[cur]=input[j];
			++j;
			count+=med-i;
		}
		++cur;
	}

	while(i<med) {
		temp[cur]=input[i];
		++i;
		++cur;
	}

	while(j<end) {
		temp[cur]=input[j];
		++j;
		++cur;
	}

	for(int i=begin; i<end; ++i) {
		input[i]=temp[i];
	}
}