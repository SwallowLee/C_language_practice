#include <iostream>
#include <vector>
#include <cstdio>
#include <climits>
#include <bitset>
#include <cmath>

using namespace std;

unsigned long long binaryToGray(unsigned long long num);
unsigned long long grayToBinary(unsigned long long num);

int main(void)
{
	int num;
	cin >> num;

	while(num--) {
		int n;
		unsigned long long times;
		int tmp;
		int number=0;

		cin >> n >> times;
		vector<bool> statues;
		//vector<bool> statues_unmodified; unused

		for(int i=0; i<n && i<64; ++i) {
			cin >> tmp;
			statues.push_back((bool)tmp);
		}

		unsigned long long copy_statues=0;
		for(int i=statues.size()-1; i>=0; --i) {
			copy_statues=copy_statues<<1;
			copy_statues+=statues[i];
		}

		for(int i=64; i<n; ++i) {
			cin >> tmp;
			//statues_unmodified.push_back((bool)tmp); unused
			if (tmp) ++number;
		}

		// possible cases of all statues being black
		if (n<=64 || number>=(n-64)) {
			unsigned long long target_times;
			if (n>=64) target_times=grayToBinary(copy_statues^ULLONG_MAX); //ULLONG_MAX=2^64-1
			else target_times=grayToBinary(copy_statues^((unsigned long long)pow(2.0f,n)-1));

			if (target_times <= times) {
				cout << n << endl;
				continue;
			}
		}

		unsigned long long gray_destination=binaryToGray(times);
		unsigned long long gray_current=copy_statues^gray_destination; // results
		while(gray_current>0) {
			number+=gray_current%2;
			gray_current=gray_current>>1;
		}

		cout << number << endl;
	}
}


// The following is from wikipedia
/*
 * This function converts an unsigned binary
 * number to reflected binary Gray code.
 *
 * The operator >> is shift right. The operator ^ is exclusive or.
 */
unsigned long long binaryToGray(unsigned long long num)
{
    return num ^ (num >> 1);
}

/*
 * This function converts a reflected binary
 * Gray code number to a binary number.
 * Each Gray code bit is exclusive-ored with all
 * more significant bits.
 */
unsigned long long grayToBinary(unsigned long long num)
{
    unsigned long long mask;
    for (mask = num >> 1; mask != 0; mask = mask >> 1)
    {
        num = num ^ mask;
    }
    return num;
}
