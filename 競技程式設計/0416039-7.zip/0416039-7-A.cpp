# include<stdio.h>
# include<vector>

using namespace std;
using std::vector;

int big,chess[8][8];
vector<int> occupy(8);
void queen(int row);
bool stand(int row,int col);
void restore(int row,int col);
int main(void)
{
    int i,j,test,ans;
    scanf("%d",&test);
    while(test!=0)
    {
        for(i=0;i<8;i++)
            for(j=0;j<8;j++)
                scanf("%d",&chess[i][j]);
        big=0;
        for(i=0;i<8;i++)
        {
            occupy.at(0)=i;
            queen(1);
        }
        printf("%5d\n",big);
        big=0;
        test--;
    }
    return 0;
}

void queen(int row)
{
    bool can;
    int i,ans;
    if(row==8)
    {
        ans=0;
        for(i=0;i<row;++i)
            ans+=chess[i][occupy.at(i)];
        if(big<ans)
            big=ans;
        return;
    }
    for(i=0;i<8;i++)
    {
        can=stand(row,i);
        if(can==true)
        {
            occupy.at(row)=i;
            queen(row+1);
        }
    }
    return;
}

bool stand(int row,int col)
{
    int i;
    for(i=0;i<row;++i)
    {
        if((row-i)==(col-occupy.at(i))||(row-i)==-(col-occupy.at(i)))
            return false;
        if(row==i)
            return false;
        if(col==occupy.at(i))
            return false;
    }
    return true;
}
