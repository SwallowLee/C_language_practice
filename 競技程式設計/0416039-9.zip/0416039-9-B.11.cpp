# include<iostream>
# include<vector>

using namespace std;
int main(void)
{
    int road,items,int_a,int_b,int_s,int_e,num,pack[52],run[52],times[52];
    int i,j,k,m,n;
    char a,b,start,end;
    bool finish;
    //0~25 capital 26~51 lower
    vector<int> connect[52],pass;
    vector<int>::iterator it;
    cin>>road;
    for(m=1;road!=-1;m++)
    {
        for(i=0;i<52;i++)
        {
            pack[i]=0;
            times[i]=0;
            run[i]=false;
        }
        k=road;
        while(k--)
        {
            cin>>a>>b;
            if(a>='A'&&a<='Z')
                int_a=a-65;
            else if(a>='a'&&a<='z')
                int_a=a-71;
            if(b>='A'&&b<='Z')
                int_b=b-65;
            else if(b>='a'&&b<='z')
                int_b=b-71;
            connect[int_a].push_back(int_b);
            connect[int_b].push_back(int_a);
        }
        cin>>items>>start>>end;
        if(start>='A'&&start<='Z')
        {
            int_s=start-65;
        }
        else if(start>='a'&&start<='z')
        {
            int_s=start-71;
        }
        if(end>='A'&&end<='Z')
        {
            int_e=end-65;
            num=items/20;
            while((num+1)*20<items+num+1)
                num++;
            pack[int_e]=items+num+1;
        }
        else if(end>='a'&&end<='z')
        {
            int_e=end-71;
            pack[int_e]=items+1;
        }
        run[int_e]=true;
        pass.push_back(int_e);
        while(!pass.empty())
        {
            int bring;
            k=pass.back();
            pass.pop_back();
            for(it=connect[k].begin();it!=connect[k].end();it++)
            {
                if(*it>=0&&*it<=25)//capital
                {
                    num=pack[k]/20;
                    while((num+1)*20<pack[k]+num+1)
                        num++;
                    bring=pack[k]+num+1;
                }
                else//lower
                {
                    bring=pack[k]+1;
                }
                if(run[*it]==false)
                {
                    if(*it!=int_s)
                    {
                        run[*it]=true;
                        pass.push_back(*it);
                        if(pack[*it]==0)
                        {
                            pack[*it]=bring;
                        }
                    }
                    else
                    {
                        times[*it]++;
                        if(pack[*it]==0)
                        {
                            pack[*it]=pack[k];
                        }
                        else
                        {
                            if(pack[*it]>pack[k])
                                pack[*it]=pack[k];
                        }
                    }
                 }
                 else
                 {
                        if(pack[*it]>bring)
                        {
                            pack[*it]=bring;
                            pass.push_back(*it);
                        }
                 }
            }
        }
        if(int_s==int_e)
            cout<<"Case "<<m<<": "<<items<<endl;
        else if(road>0)
            cout<<"Case "<<m<<": "<<pack[int_s]<<endl;
        else
            cout<<"Case "<<m<<": 0"<<endl;
        for(i=0;i<52;i++)
        {
            connect[i].clear();
        }
        cin>>road;
    }
    return 0;
}
